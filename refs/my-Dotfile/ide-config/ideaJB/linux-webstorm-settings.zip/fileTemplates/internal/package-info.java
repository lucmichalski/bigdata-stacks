#parse("File Header.java")
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

/**
 *  Author      :   AlanDing
 *  Time        :   ${DATE} ${TIME}
 *  File        :   ${NAME}.java
 *  Description :   
 */