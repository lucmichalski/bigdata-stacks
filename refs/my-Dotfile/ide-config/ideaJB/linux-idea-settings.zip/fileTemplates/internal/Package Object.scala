
#if ((${PACKAGE_QUALIFIER} && ${PACKAGE_QUALIFIER} != ""))package ${PACKAGE_QUALIFIER} #end
#parse("File Header.java")

/**
 *  @Author      :  AlanDing
 *  @Time        :  ${DATE} ${TIME}
 *  @File        :  ${NAME}.scala
 *  @Description :   
 */

package object ${PACKAGE_SIMPLE_NAME} {

}
