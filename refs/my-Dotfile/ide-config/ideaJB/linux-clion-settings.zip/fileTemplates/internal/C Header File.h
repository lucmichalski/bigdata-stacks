// ${NAME}.h //

/**
 * File Name    : ${NAME}
 * Author       : AlanDing
 * Created Time : ${DATE} ${TIME}
 * Description  :
 */

#[[#ifndef]]# ${INCLUDE_GUARD}
#[[#define]]# ${INCLUDE_GUARD}


 
#[[#endif]]# //${INCLUDE_GUARD}
