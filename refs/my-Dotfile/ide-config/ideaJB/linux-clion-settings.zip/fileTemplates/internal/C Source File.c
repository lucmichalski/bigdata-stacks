// ${NAME}.c //

/**
 * File Name    : ${NAME}
 * Author       : AlanDing
 * Created Time : ${DATE} ${TIME}
 * Description  :
 */

#if (${HEADER_FILENAME})
#[[#include]]# "${HEADER_FILENAME}"




#end


