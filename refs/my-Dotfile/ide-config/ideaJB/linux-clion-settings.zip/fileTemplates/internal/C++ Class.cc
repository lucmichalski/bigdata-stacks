// ${NAME}.cpp //

/**
 * File Name    : ${NAME}
 * Author       : AlanDing
 * Created Time : ${DATE} ${TIME}
 * Description  :
 */

#[[#include]]# "${HEADER_FILENAME}"

