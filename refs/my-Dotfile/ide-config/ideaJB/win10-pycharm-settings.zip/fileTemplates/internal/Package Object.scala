/*
 @Author   :   AlanDing
 @Time     :   ${DATE} ${TIME}
 @File     :   ${NAME}.scala
*/

#if ((${PACKAGE_QUALIFIER} && ${PACKAGE_QUALIFIER} != ""))package ${PACKAGE_QUALIFIER} #end
#parse("File Header.java")
package object ${PACKAGE_SIMPLE_NAME} {

}
